from html import escape

from AccessControl import ClassSecurityInfo
from AccessControl.Permissions import manage_users
from OFS.SimpleItem import SimpleItem

from .config import (
    DEFAULT_FALLBACK_LOGIN,
    DEFAULT_MIGRATION_SQL_ID,
    DEFAULT_MIGRATION_TABLES_ID,
    DEFAULT_TABLES,
    DEFAULT_TOTP_ISSUER,
    DEFAULT_WIZARD_ID,
    MODE_AUTH_ONLY,
    MODE_MANAGED,
    classic_acl_users_migration_template,
)
from .compat import InitializeClass
from .installer import SQLUserWizardInstaller


class SQLUserWizard(SimpleItem):
    """ZMI helper that installs and repairs a SQL-backed PAS setup."""

    meta_type = "SQL User Wizard"
    security = ClassSecurityInfo()
    security.declareObjectProtected(manage_users)

    connection_id = "pg_odbc"
    dialect = "postgresql"
    mode = MODE_MANAGED
    users_table = DEFAULT_TABLES["users"]
    profiles_table = DEFAULT_TABLES["profiles"]
    roles_table = DEFAULT_TABLES["roles"]
    user_roles_table = DEFAULT_TABLES["user_roles"]
    fallback_login = DEFAULT_FALLBACK_LOGIN
    initial_user_id = ""
    initial_login_name = ""
    initial_roles = "Manager"
    seed_standard_roles = True
    totp_issuer = DEFAULT_TOTP_ISSUER

    def __init__(self, id=DEFAULT_WIZARD_ID):
        self.id = id

    manage_options = (
        {"label": "Wizard", "action": "manage_main"},
        {"label": "Security", "action": "manage_access"},
    )

    security.declareProtected(manage_users, "manage_main")

    def manage_main(self, REQUEST=None):
        """Render and run the SQL User Wizard management screen."""

        if REQUEST is not None:
            REQUEST.RESPONSE.setHeader("Content-Type", "text/html; charset=utf-8")

        message = ""
        if REQUEST is not None and REQUEST.get("prepare_managed_migration"):
            self._capture_form_values(REQUEST)
            self._prepare_managed_migration()
            message = self._format_notice(
                "Managed migration prepared",
                "Run the starter SQL against a database copy, verify the new "
                "tables, then run Install / Repair SQL PAS in managed mode.",
            )
        elif REQUEST is not None and REQUEST.get("check_migration_status"):
            self._capture_form_values(REQUEST)
            message = self._format_migration_status()
        elif REQUEST is not None and REQUEST.get("run_wizard"):
            self._capture_form_values(REQUEST)
            fallback_password = REQUEST.get("fallback_password", "")
            result = self.install_or_repair(
                fallback_password=fallback_password,
                initial_password=REQUEST.get("initial_password", ""),
            )
            message = self._format_result(result)

        return self._render_form(message)

    def _capture_form_values(self, REQUEST):
        self.connection_id = REQUEST.get("connection_id", self.connection_id)
        self.dialect = REQUEST.get("dialect", self.dialect)
        self.mode = REQUEST.get("mode", self.mode)
        self.users_table = REQUEST.get("users_table", self.users_table)
        self.profiles_table = REQUEST.get("profiles_table", self.profiles_table)
        self.roles_table = REQUEST.get("roles_table", self.roles_table)
        self.user_roles_table = REQUEST.get(
            "user_roles_table", self.user_roles_table
        )
        self.fallback_login = REQUEST.get("fallback_login", self.fallback_login)
        self.initial_user_id = REQUEST.get("initial_user_id", self.initial_user_id)
        self.initial_login_name = REQUEST.get(
            "initial_login_name", self.initial_login_name
        )
        self.initial_roles = REQUEST.get("initial_roles", self.initial_roles)
        self.seed_standard_roles = bool(REQUEST.get("seed_standard_roles", ""))
        self.totp_issuer = REQUEST.get("totp_issuer", self.totp_issuer)

    def _prepare_managed_migration(self):
        self.mode = MODE_MANAGED
        if self.dialect == "existing_oracle":
            self.dialect = "oracle11g"
        elif self.dialect == "existing_postgresql":
            self.dialect = "postgresql"
        self.users_table = "pas_users_migrated"
        self.user_roles_table = "pas_user_roles_migrated"

    def _format_notice(self, title, body):
        return (
            "<section class='result'><h2>"
            f"{escape(title)}</h2><p>{escape(body)}</p></section>"
        )

    def _format_migration_status(self):
        try:
            rows = self._migration_table_rows()
        except Exception as exc:
            return self._format_notice(
                "Migration status unavailable",
                "Run auth-only Install / Repair first, open the database "
                f"connection, then try again. Details: {exc}",
            )

        existing = {str(getattr(row, "table_name", "")).lower() for row in rows}
        expected = self._expected_migration_tables()
        old_tables = {self.users_table.lower(), self.user_roles_table.lower()}
        new_tables = {"pas_users_migrated", "pas_user_roles_migrated"}
        support_tables = {self.profiles_table.lower(), self.roles_table.lower()}

        missing_old = sorted(old_tables - existing)
        existing_new = sorted(new_tables & existing)
        missing_new = sorted(new_tables - existing)
        existing_support = sorted(support_tables & existing)
        missing_support = sorted(support_tables - existing)

        items = []
        if missing_old:
            items.append(
                "Classic source table(s) missing: "
                + ", ".join(f"<code>{escape(name)}</code>" for name in missing_old)
            )
        if existing_support and missing_new:
            items.append(
                "Support table name collision before migration: "
                + ", ".join(f"<code>{escape(name)}</code>" for name in existing_support)
                + ". Use different support table names or remove/rename those tables "
                "before running the starter SQL."
            )
        if missing_new:
            items.append(
                "Managed takeover is not ready yet. Missing migrated table(s): "
                + ", ".join(f"<code>{escape(name)}</code>" for name in missing_new)
            )
        if missing_support:
            items.append(
                "Support table(s) not present yet: "
                + ", ".join(f"<code>{escape(name)}</code>" for name in missing_support)
            )
        if not missing_old and not missing_new and not missing_support:
            items.append(
                "Ready for managed takeover. Press "
                "<strong>Prepare wizard for managed takeover</strong>, then run "
                "<strong>Install / Repair SQL PAS</strong>."
            )

        seen = ", ".join(f"<code>{escape(name)}</code>" for name in sorted(existing))
        expected_text = ", ".join(
            f"<code>{escape(name)}</code>" for name in sorted(expected)
        )
        return (
            "<section class='result'><h2>Classic migration status</h2>"
            f"<p class='note'>Expected tables checked: {expected_text}</p>"
            f"<p class='note'>Existing matching tables: {seen or 'none'}</p>"
            "<ul class='clean-list warnings'>"
            + "".join(f"<li>{item}</li>" for item in items)
            + "</ul></section>"
        )

    def _migration_table_rows(self):
        plugin = self.aq_parent.acl_users.sql_auth
        return list(getattr(plugin, DEFAULT_MIGRATION_TABLES_ID)())

    def _expected_migration_tables(self):
        return {
            "pas_users_migrated",
            "pas_user_roles_migrated",
            self.profiles_table.lower(),
            self.roles_table.lower(),
            self.users_table.lower(),
            self.user_roles_table.lower(),
        }

    security.declareProtected(manage_users, "manage_workspace")

    def manage_workspace(self, REQUEST=None):
        """Render the default ZMI workspace for this object."""

        return self.manage_main(REQUEST)

    security.declareProtected(manage_users, "index_html")

    def index_html(self, REQUEST=None):
        """Render the wizard when opened directly."""

        return self.manage_main(REQUEST)

    security.declareProtected(manage_users, "install_or_repair")

    def install_or_repair(self, fallback_password="", initial_password=""):
        """Install or repair the SQL-backed PAS setup in the parent folder."""

        tables = {
            "users": self.users_table,
            "profiles": self.profiles_table,
            "roles": self.roles_table,
            "user_roles": self.user_roles_table,
        }
        initial_user = {}
        if self.mode != MODE_AUTH_ONLY and self.initial_user_id.strip():
            initial_user = {
                "user_id": self.initial_user_id.strip(),
                "login_name": (
                    self.initial_login_name.strip() or self.initial_user_id.strip()
                ),
                "password": initial_password,
                "password_hash_id": "authencoding",
                "recovery_email": "",
                "first_name": "",
                "last_name": "",
                "display_name": "",
                "email": "",
                "mobile": "",
                "enabled": True,
                "roles_text": self.initial_roles,
            }
        installer = SQLUserWizardInstaller(
            folder=self.aq_parent,
            connection_id=self.connection_id,
            dialect=self.dialect,
            tables=tables,
            fallback_login=self.fallback_login,
            fallback_password=fallback_password,
            initial_user=initial_user,
            seed_roles=self.seed_standard_roles,
            mode=self.mode,
            totp_issuer=self.totp_issuer,
        )
        return installer.install()

    def _format_result(self, result):
        lines = ["<section class='result'><h2>Install / Repair Result</h2>"]
        if result.actions:
            lines.append("<h3>Actions</h3><ul class='clean-list'>")
            lines.extend(f"<li>{escape(line)}</li>" for line in result.actions)
            lines.append("</ul>")
        if result.warnings:
            lines.append("<h3>Warnings</h3><ul class='clean-list warnings'>")
            lines.extend(f"<li>{escape(line)}</li>" for line in result.warnings)
            lines.append("</ul>")
        lines.append("</section>")
        return "\n".join(lines)

    def _render_form(self, message):
        connection_id = escape(self.connection_id)
        mode = escape(self.mode)
        dialect = escape(self.dialect)
        users_table = escape(self.users_table)
        profiles_table = escape(self.profiles_table)
        roles_table = escape(self.roles_table)
        user_roles_table = escape(self.user_roles_table)
        seed_checked = "checked" if self.seed_standard_roles else ""
        fallback_login = escape(self.fallback_login)
        initial_user_id = escape(self.initial_user_id)
        initial_login_name = escape(self.initial_login_name)
        initial_roles = escape(self.initial_roles)
        totp_issuer = escape(self.totp_issuer)
        preflight = self._render_preflight()
        return f"""<!doctype html>
<html>
<head>
  <title>SQL User Wizard</title>
  <style>
    body {{ font-family: system-ui, sans-serif; margin: 0; color: #172033; background: #eef2f6; }}
    main {{ max-width: 1040px; margin: 0 auto; padding: 2rem; box-sizing: border-box; }}
    header {{ margin-bottom: 1.25rem; }}
    h1 {{ margin: 0 0 .35rem; font-size: 1.8rem; }}
    h2 {{ margin: 0 0 .75rem; font-size: 1.15rem; }}
    h3 {{ margin: 1rem 0 .4rem; font-size: 1rem; }}
    p {{ line-height: 1.5; }}
    label {{ display: block; margin: .75rem 0; font-weight: 650; }}
    input, select {{ box-sizing: border-box; display: block; width: 100%; margin-top: .3rem; padding: .55rem .65rem; border: 1px solid #b8c2cf; font: inherit; background: #fff; }}
    input:focus, select:focus {{ outline: 2px solid #6797c6; outline-offset: 1px; }}
    .checkbox-label {{ display: flex; align-items: center; gap: .5rem; }}
    .checkbox-label input {{ width: auto; margin-top: 0; }}
    button {{ padding: .75rem 1rem; border: 0; background: #20663f; color: #fff; font: inherit; font-weight: 750; cursor: pointer; }}
    button:hover {{ background: #185532; }}
    fieldset {{ border: 1px solid #d5dbe3; margin: 0; padding: 1rem; }}
    legend {{ padding: 0 .35rem; font-weight: 750; }}
    .note {{ color: #596579; }}
    .panel, .result {{ background: #fff; border: 1px solid #d5dbe3; padding: 1.25rem; margin: 1rem 0; box-shadow: 0 12px 34px rgba(20, 34, 52, .07); }}
    .grid {{ display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 1rem; }}
    .wide {{ grid-column: 1 / -1; }}
    .help {{ margin: .35rem 0 0; color: #667085; font-size: .93rem; }}
    .clean-list {{ margin: .5rem 0 0; padding: 0; list-style: none; display: grid; gap: .35rem; }}
    .clean-list li {{ padding: .45rem .6rem; background: #eef8f0; border-left: 4px solid #17803a; }}
    .clean-list.warnings li {{ background: #fff7e8; border-left-color: #d29528; }}
    .clean-list.danger li {{ background: #fff1f0; border-left-color: #b42318; }}
    .preflight strong {{ display: inline-block; min-width: 7.5rem; }}
    .preflight code {{ background: #f6f7f9; padding: .1rem .25rem; }}
    .preflight pre {{ overflow: auto; padding: .85rem; background: #172033; color: #f8fafc; }}
    .migration-sql {{ margin-top: .85rem; }}
    .zmi-links {{ display: flex; gap: .75rem; flex-wrap: wrap; margin-top: .75rem; }}
    .zmi-links a {{ color: #0b5c92; font-weight: 700; text-decoration: none; }}
    .zmi-links a:hover {{ text-decoration: underline; }}
    .summary {{ display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: .75rem; margin-top: 1rem; }}
    .summary div {{ background: #fff; border: 1px solid #d5dbe3; padding: .85rem; }}
    .summary strong {{ display: block; margin-bottom: .25rem; }}
    @media (max-width: 760px) {{
      main {{ padding: 1rem; }}
      .grid, .summary {{ grid-template-columns: 1fr; }}
      .wide {{ grid-column: auto; }}
    }}
  </style>
</head>
<body>
  <main>
    <header>
      <h1>SQL User Wizard</h1>
      <p class="note">Install or repair a local PAS setup backed by Z SQL
      Methods. Use auth-only as a read-only proof against an existing
      Zope-style user database, or managed mode when this product should own
      the user and role tables.</p>
      <nav class="zmi-links">
        <a href="{self._zmi_parent_workspace_url()}">Back to containing folder</a>
        <a href="{self._zmi_root_workspace_url()}">Zope root</a>
      </nav>
    </header>
    {message}
    {preflight}
    <form method="post" class="panel">
      <input type="hidden" name="run_wizard" value="1">
      <div class="grid">
        <fieldset>
          <legend>Database</legend>
          <label>Connection id
            <input name="connection_id" value="{connection_id}">
          </label>
          <label>Install mode
            <select name="mode">
              <option value="{MODE_MANAGED}" {'selected' if self.mode == MODE_MANAGED else ''}>Managed tables</option>
              <option value="{MODE_AUTH_ONLY}" {'selected' if self.mode == MODE_AUTH_ONLY else ''}>Existing schema / auth-only</option>
            </select>
          </label>
          <label>SQL dialect
            <select name="dialect">
              <option value="postgresql" {'selected' if self.dialect == 'postgresql' else ''}>PostgreSQL managed</option>
              <option value="sqlite" {'selected' if self.dialect == 'sqlite' else ''}>SQLite managed</option>
              <option value="mysql" {'selected' if self.dialect == 'mysql' else ''}>MySQL / MariaDB managed</option>
              <option value="mssql" {'selected' if self.dialect == 'mssql' else ''}>Microsoft SQL Server managed</option>
              <option value="oracle11g" {'selected' if self.dialect in ('oracle', 'oracle11g') else ''}>Oracle 11g managed</option>
              <option value="oracle12c" {'selected' if self.dialect == 'oracle12c' else ''}>Oracle 12c+ managed</option>
              <option value="existing_postgresql" {'selected' if self.dialect == 'existing_postgresql' else ''}>Existing PostgreSQL auth-only</option>
              <option value="existing_oracle" {'selected' if self.dialect == 'existing_oracle' else ''}>Existing Oracle auth-only</option>
            </select>
          </label>
          <p class="help">Managed mode creates product-owned tables. Auth-only
          mode only reads an existing Zope-style user schema and is the safe
          first step before taking control.</p>
        </fieldset>
        <fieldset>
          <legend>Fallback Access</legend>
          <label>Extra fallback manager login
            <input name="fallback_login" value="{fallback_login}">
          </label>
          <label>Extra fallback manager password
            <input name="fallback_password" type="password" value="">
          </label>
          <p class="help">Parent-folder users are synced automatically. These
          fields only create one additional local recovery user.</p>
        </fieldset>
        <fieldset class="wide">
          <legend>SQL Tables</legend>
          <div class="grid">
            <label>Users table
              <input name="users_table" value="{users_table}">
            </label>
            <label>Profiles table
              <input name="profiles_table" value="{profiles_table}">
            </label>
            <label>Roles catalog table
              <input name="roles_table" value="{roles_table}">
            </label>
            <label class="checkbox-label">
              <input name="seed_standard_roles" type="checkbox" value="1" {seed_checked}>
              Seed standard Zope roles
            </label>
            <label>User roles table
              <input name="user_roles_table" value="{user_roles_table}">
            </label>
          </div>
          <p class="help">For existing-schema auth-only, use <code>users</code> and
          <code>roles</code>. Profile/user-role tables are ignored. Standard
          role seeding creates missing <code>Manager</code>, <code>Owner</code>,
          <code>Authenticated</code>, and <code>Anonymous</code> role catalog
          rows without assigning them to users.</p>
        </fieldset>
        <fieldset class="wide">
          <legend>Authenticator</legend>
          <label>Issuer / app name
            <input name="totp_issuer" value="{totp_issuer}">
          </label>
          <p class="help">This is the app name shown by Authenticator apps.
          Use one shared issuer for all lab folders, for example
          <code>SQL_User_Wizard</code>. Production installations should choose
          their own application name.</p>
        </fieldset>
        <fieldset class="wide">
          <legend>First SQL User</legend>
          <div class="grid">
            <label>User id
              <input name="initial_user_id" value="{initial_user_id}">
            </label>
            <label>Login name
              <input name="initial_login_name" value="{initial_login_name}">
            </label>
            <label>Password
              <input name="initial_password" type="password" value="">
            </label>
            <label>Roles
              <input name="initial_roles" value="{initial_roles}">
            </label>
          </div>
          <p class="help">Ignored in auth-only mode. Existing database users
          are authenticated read-only. For unrelated legacy schemas, import
          users into the managed model with custom scripts.</p>
        </fieldset>
      </div>
      <button type="submit">Install / Repair SQL PAS</button>
    </form>
    <section class="summary">
      <div><strong>Local PAS</strong><code>acl_users</code> with SQL auth and cookie login.</div>
      <div><strong>User Tools</strong>Managed mode installs admin/profile tools; auth-only installs read-only login and diagnostics.</div>
      <div><strong>Mode</strong>{mode} / {dialect}</div>
    </section>
  </main>
</body>
</html>"""

    def _zmi_parent_workspace_url(self):
        parent = getattr(self, "aq_parent", None)
        if parent is not None and hasattr(parent, "absolute_url_path"):
            return escape(f"{parent.absolute_url_path()}/manage_workspace")
        return "../manage_workspace"

    def _zmi_root_workspace_url(self):
        return "/manage_workspace"

    def _render_preflight(self):
        groups = self._preflight_groups()
        sections = []
        for css_class, title, items in groups:
            if not items:
                continue
            sections.append(
                f"<h3>{escape(title)}</h3><ul class='clean-list {css_class}'>"
            )
            sections.extend(f"<li>{item}</li>" for item in items)
            sections.append("</ul>")
        migration_summary = (
            self._render_auth_only_migration_summary()
            if self.mode == MODE_AUTH_ONLY
            else ""
        )
        return f"""
    <section class="panel preflight">
      <h2>Preflight</h2>
      <p class="note">Read this before running install/repair. Existing
      databases may mix authentication fields, profile fields, and application
      data in the same tables.</p>
      {''.join(sections)}
      {migration_summary}
    </section>
"""

    def _render_auth_only_migration_summary(self):
        users = escape(self.users_table)
        roles = escape(self.user_roles_table)
        profiles = escape(self.profiles_table)
        catalog = escape(self.roles_table)
        managed_dialect = escape(self._managed_migration_dialect())
        sql = escape(self._auth_only_migration_sql())
        return f"""
      <h3>Classic acl_users Migration</h3>
      <ul class="clean-list">
        <li><strong>Recognized shape</strong> Auth-only expects
        <code>{users}.username</code>, <code>{users}.password</code>,
        <code>{roles}.username</code>, and <code>{roles}.role</code>. The
        wizard maps <code>username</code> to its internal
        <code>login_name</code>.</li>
        <li><strong>Managed gap</strong> Managed mode additionally needs
        <code>password_hash_id</code>, <code>enabled</code>,
        <code>totp_required</code>, <code>totp_enabled</code>,
        <code>totp_secret</code>, and <code>recovery_email</code> on users,
        and role assignments as <code>user_id</code>/<code>role_id</code>.</li>
        <li><strong>Profile split</strong> Fields such as
        <code>firstname</code>, <code>lastname</code>, email, phone, theme,
        language, company, notes, and other application data should move to
        <code>{profiles}</code> or an application table, not stay in the
        managed security table.</li>
        <li><strong>Safer takeover</strong> Prefer creating managed
        <code>pas_*</code> tables from the classic tables, then point the
        wizard at those managed tables. Keep the old tables read-only until
        the application has been tested.</li>
      </ul>
      <details class="migration-sql">
        <summary>Suggested starter SQL for a classic acl_users migration</summary>
        <p class="note">Review and run manually against a copy first. The SQL
        assumes the classic table names currently entered above and creates
        product-owned managed tables.</p>
        <pre>{sql}</pre>
      </details>
      <form method="post" class="migration-sql">
        {self._managed_migration_hidden_fields()}
        <p class="note">After running and verifying the SQL, the wizard should
        be switched to these managed settings: dialect
        <code>{managed_dialect}</code>, users table
        <code>pas_users_migrated</code>, profiles table
        <code>{profiles}</code>, roles catalog table <code>{catalog}</code>,
        and user roles table <code>pas_user_roles_migrated</code>.</p>
        <p class="note">Install/repair also creates the same SQL as
        <code>acl_users/sql_auth/{DEFAULT_MIGRATION_SQL_ID}</code>. Open that
        Z SQL Method in ZMI and use its Test tab when you want Zope to run the
        migration SQL through the selected database adapter. It also creates
        <code>acl_users/sql_auth/{DEFAULT_MIGRATION_TABLES_ID}</code>, used by
        the status check below.</p>
        <button type="submit" name="check_migration_status" value="1">
          Check migration status
        </button>
        <button type="submit" name="prepare_managed_migration" value="1">
          Prepare wizard for managed takeover
        </button>
      </form>
"""

    def _managed_migration_dialect(self):
        if self.dialect == "existing_oracle":
            return "oracle11g"
        if self.dialect == "existing_postgresql":
            return "postgresql"
        return self.dialect

    def _managed_migration_hidden_fields(self):
        fields = {
            "connection_id": self.connection_id,
            "dialect": self.dialect,
            "mode": self.mode,
            "users_table": self.users_table,
            "profiles_table": self.profiles_table,
            "roles_table": self.roles_table,
            "user_roles_table": self.user_roles_table,
            "fallback_login": self.fallback_login,
            "initial_user_id": self.initial_user_id,
            "initial_login_name": self.initial_login_name,
            "initial_roles": self.initial_roles,
            "totp_issuer": self.totp_issuer,
        }
        if self.seed_standard_roles:
            fields["seed_standard_roles"] = "1"
        return "\n".join(
            f'<input type="hidden" name="{escape(name)}" value="{escape(str(value))}">'
            for name, value in fields.items()
        )

    def _auth_only_migration_sql(self):
        return classic_acl_users_migration_template(
            self.dialect,
            {
                "users": self.users_table,
                "profiles": self.profiles_table,
                "roles": self.roles_table,
                "user_roles": self.user_roles_table,
            },
        )["template"]

    def _preflight_groups(self):
        table_values = {
            "Users": self.users_table,
            "Profiles": self.profiles_table,
            "Roles catalog": self.roles_table,
            "User roles": self.user_roles_table,
        }
        errors = []
        warnings = []
        checks = []

        normalized = {}
        for label, value in table_values.items():
            key = (value or "").strip().lower()
            if not key:
                errors.append(
                    f"<strong>{escape(label)}</strong> Table name is empty."
                )
                continue
            if key in normalized:
                errors.append(
                    f"<strong>{escape(label)}</strong> Reuses "
                    f"<code>{escape(value)}</code> from "
                    f"{escape(normalized[key])}. Use distinct tables."
                )
            normalized[key] = label

        if self.mode == MODE_AUTH_ONLY:
            checks.append(
                "<strong>Auth-only</strong> Installs read-only Z SQL Methods "
                "for authentication, role lookup, and profile display."
            )
            checks.append(
                "<strong>No writes</strong> Auth-only mode must not create, "
                "alter, update, delete, or insert database rows."
            )
            if not self.dialect.startswith("existing_"):
                warnings.append(
                    "<strong>Dialect</strong> Auth-only is meant for "
                    "<code>existing_postgresql</code> or "
                    "<code>existing_oracle</code>. Managed dialects are for "
                    "product-owned tables."
                )
            checks.append(
                "<strong>Managed later</strong> A green auth-only test proves "
                "only <code>username</code>, <code>password</code>, and role "
                "lookup. Managed mode also needs <code>password_hash_id</code>, "
                "<code>enabled</code>, <code>totp_required</code>, "
                "<code>totp_enabled</code>, <code>totp_secret</code>, and "
                "<code>recovery_email</code> in the users table, plus a "
                "<code>role_id</code>-based assignment table."
            )
        else:
            checks.append(
                "<strong>Managed</strong> Install/repair may create or alter "
                "security tables and may update users, roles, profiles, and "
                "2FA fields."
            )
            if self.dialect.startswith("existing_"):
                warnings.append(
                    "<strong>Mode mismatch</strong> Existing-schema dialects "
                    "are read-only proofs. Use a managed dialect only when the "
                    "product should own or repair the target tables."
                )

        application_named = [
            value
            for value in table_values.values()
            if value and not value.strip().lower().startswith("pas_")
        ]
        if self.mode != MODE_AUTH_ONLY and application_named:
            warnings.append(
                "<strong>Existing names</strong> These table names do not look "
                f"product-owned: <code>{escape(', '.join(application_named))}</code>. "
                "Managed users require <code>user_id</code>, <code>username</code>, "
                "<code>password</code>, <code>password_hash_id</code>, "
                "<code>enabled</code>, and 2FA/recovery columns. Managed role "
                "assignments require <code>user_id</code> and <code>role_id</code>. "
                "Before repair, separate identity/security fields from editable "
                "profile fields and application-only data."
            )

        if self.mode != MODE_AUTH_ONLY:
            checks.append(
                "<strong>Profile split</strong> Keep passwords, enabled status, "
                "2FA, and recovery data in the users table. Put first name, "
                "last name, display name, email, and mobile in the profiles "
                "table unless the application deliberately syncs selected "
                "fields elsewhere."
            )
            checks.append(
                "<strong>App data</strong> Internal notes, employment status, "
                "business roles, addresses, dates, avatar blobs, and other "
                "domain fields belong to application tables. Do not expose them "
                "through self-service profile forms without an explicit sync rule."
            )

        return (
            ("danger", "Stop First", errors),
            ("warnings", "Review", warnings),
            ("", "Expected Behavior", checks),
        )


InitializeClass(SQLUserWizard)


def manage_addSQLUserWizard(self, id=DEFAULT_WIZARD_ID, title="", REQUEST=None):
    """Add a SQL User Wizard to a folder."""

    if REQUEST is not None and REQUEST.get("REQUEST_METHOD", "GET").upper() != "POST":
        from .browser import manage_addSQLUserWizardForm

        return manage_addSQLUserWizardForm(self, REQUEST)

    wizard = SQLUserWizard(id)
    wizard.title = title or "SQL User Wizard"
    self._setObject(id, wizard)
    if REQUEST is not None:
        REQUEST.RESPONSE.redirect(f"{self.absolute_url()}/{id}/manage_main")
    return id
